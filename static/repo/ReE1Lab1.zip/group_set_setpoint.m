function response = group_set_setpoint(group_number, mech_power_perc, rotor_current_perc)


mech_power_perc = min(mech_power_perc, 10);
rotor_current_perc = min(rotor_current_perc, 20);

request = {};

request.torque = mech_power_perc;
request.stator_current = rotor_current_perc;


json_input_string = jsonencode(request);

response = write_to_middleware(json_input_string, 1230+group_number);


end