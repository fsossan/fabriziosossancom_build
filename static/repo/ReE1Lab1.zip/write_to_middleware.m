function json_output = write_to_middleware(json_string, port)
    % Utility function to write a json packet to some tcp-socket-based middleware.
    host = '10.30.5.174';
    iter_max = 50;
    
    t = tcpclient(host, port);
    write(t, json_string);
    
    % Read data from TCP/IP socket
    i = 0;
    while 1
        if t.NumBytesAvailable > 0
            break
        end
        pause(0.04)
        i = i + 1;
        if i >= iter_max
            error('Received nothing from the socket for some time. Quitting.');
            
        end
    end
    
    data = read(t,t.NumBytesAvailable, "string");
    % Close socket connection
    clear t;
    
    json_output = jsondecode(data);
end